import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPanel;
import java.awt.GridLayout;

public class Middle extends JPanel {
	
	public Middle () {
   setLayout(new GridLayout(5,2));



add(new JLabel("ID:"));
add(new JTextField(10));
add(new JLabel("First Name:"));
add(new JTextField(10));
add(new JLabel("Last Name:"));
add(new JTextField(10));
add(new JLabel("Email:"));
add(new JTextField(10));
add(new JLabel("GPA:"));
add(new JTextField(5));





}
 }