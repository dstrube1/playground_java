import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.WindowEvent;  
import javax.swing.JFrame;  
import javax.swing.JOptionPane;

public class Bottom extends JPanel {
	
	public Bottom() {
   
      JPanel mp1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 1, 1));
      JPanel mp2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 2));
      JButton bOne = new JButton("Find ");
      JButton bTwo = new JButton("Insert");
      JButton bThree = new JButton("Delete");
      JButton bFour = new JButton("Update ");
      JButton bFive = new JButton("Exit");
            
      mp1.add(bOne);
      mp1.add(bTwo);
      mp1.add(bThree);
      mp1.add(bFour);
      mp1.add(bFive);
      
            
         
      setLayout(new GridLayout(2,1,5,5));
      add(mp1); 
      
 
      
      }                
                }

     
  
