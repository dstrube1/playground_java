/*
 * JavaFxScriptLauncher.java
 * 
 * Created on Aug 8, 2007, 1:17:31 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javafxscriptlauncher;

import java.io.InputStreamReader;
import java.util.Date;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
//import newFXGUI;

import net.java.javafx.FXShell;

/**
 *
 * @author sridhar
 */
public class JavaFxScriptLauncher {

    public JavaFxScriptLauncher() {
    }

    public static void anotherWayToLaunchJavaFX () {
        System.out.println("In anotherWayToLaunchJavaFX()");
        try {
            FXShell.main(new String[] {"HelloWorld.fx"});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        try {
            // set up script:
            System.out.println("In main();");
            
            System.out.println("In main(): Calling anotherWayToLaunchJavaFX");
            //anotherWayToLaunchJavaFX();
                    try {
            FXShell.main(new String[] {"HelloWorld.fx"});
        } catch (Exception e) {
            e.printStackTrace();
        }
            
            
            
            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByExtension("fx");
            
            engine.put("argnow:java.util.Date", new Date());           
            engine.put("winwidth:int", 600);           
            engine.put("winheight:Number",new Integer(100) );           
            
            InputStreamReader reader = 
                    new InputStreamReader(JavaFxScriptLauncher.class
                    .getResourceAsStream("HelloWorld.fx"));
            engine.eval(reader);
            

            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
