src/trunk/demos/javafxpad/javafxpad.sh
