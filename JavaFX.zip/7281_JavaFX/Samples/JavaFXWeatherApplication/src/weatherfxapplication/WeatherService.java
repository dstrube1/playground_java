package weatherfxapplication;

import java.util.ArrayList;

public class WeatherService {
    WeatherData data;
    
    public WeatherService() {
        data = new WeatherData();
    }
    
    public ArrayList getWeatherInfos() {
        return data.getWeatherInfos();
    }
    
    public WeatherInfo getWeatherInfo(String date) {
        WeatherInfo info;
        for (int i=0; i<data.getSize();i++) {
            info = (WeatherInfo) data.getWeatherInfos().get(i);
            if (info.getDate().equalsIgnoreCase(date)) {
                return info;
            }
        }
        return null;
    }

    public WeatherInfo getWeatherInfo(int date) {
        WeatherInfo info;
        for (int i=0; i<data.getSize();i++) {
            info = (WeatherInfo) data.getWeatherInfos().get(i);
            if (info.getDateValue() == date) {
                return info;
            }
        }
        return null;
    }
    
    public WeatherInfo[] getWeatherInfo() {
        WeatherInfo[] info = new WeatherInfo[data.getSize()];
        for(int i=0; i<info.length; i++) {
            info[i] = (WeatherInfo) data.getWeatherInfos().get(i);
        }
        return info;
    }
}
