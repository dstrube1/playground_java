package weatherfxapplication;

public class WeatherInfo {

    String date;
    String location;
    String temperature;
    String wind;
    String pressure;
    String humidity;
    String forecast;

    protected WeatherInfo(String date, String location, String temperature, String wind, String pressure, String humidity, String forecast) {
        this.date = date;
        this.location = location;
        this.temperature = temperature;
        this.wind = wind;
        this.pressure = pressure;
        this.humidity = humidity;
        this.forecast = forecast;
    }

    public String getDate() {
        return date;
    }
    
    public int getDateValue() {
        return new Integer(date.substring(0, date.indexOf('.')));
    }

    public String getLocation() {
        return location;
    }

    public String getTemperature() {
        return temperature;
    }

    public int getTemperatureValue() {
        return new Integer(temperature.substring(0,temperature.indexOf('C'))).intValue();
    }
    public String getWind() {
        return wind;
    }
    
    public String getWindDirection() {
        return wind.substring(0, wind.indexOf(','));
    }
    
    public int getWindSpeed() {
        return new Integer(wind.substring(wind.indexOf(',')+2, wind.indexOf("m/s")-1)).intValue();
    }

    public String getPressure() {
        return pressure;
    }

    public String getHumidity() {
        return humidity;
    }

    public String getForecast() {
        return forecast;
    }
}
