package weatherfxapplication;

import java.util.ArrayList;

 class WeatherData {
    String location = "JavaFX City";
    ArrayList<WeatherInfo> weatherInfos; 
    //ExtendedWeatherInfo[] extendedInfos = {new ExtendedWeatherInfo()};
    
    protected WeatherData() {
        weatherInfos = new ArrayList<WeatherInfo>();
        weatherInfos.add(new WeatherInfo("01.08.2007",location,"20C","N, 4 m/sec","750mm","81%","sunny"));
        weatherInfos.add(new WeatherInfo("02.08.2007",location,"25C","NW, 5 m/sec","755mm","90%","partly cloudy"));
        weatherInfos.add(new WeatherInfo("03.08.2007",location,"18C","S, 2 m/sec","755mm","70%","rainy"));
        weatherInfos.add(new WeatherInfo("04.08.2007",location,"17C","SW, 9 m/sec","755mm","95%","sunny"));
        weatherInfos.add(new WeatherInfo("05.08.2007",location,"30C","SE, 4 m/sec","755mm","99%","mostly cloudy"));
        weatherInfos.add(new WeatherInfo("06.08.2007",location,"20C","N, 4 m/sec","755mm","80%","cloudy"));
        weatherInfos.add(new WeatherInfo("07.08.2007",location,"25C","W, 4 m/sec","755mm","91%","sunny"));
        weatherInfos.add(new WeatherInfo("08.08.2007",location,"23C","E, 4 m/sec","755mm","85%","rainy"));
        weatherInfos.add(new WeatherInfo("09.08.2007",location,"22C","NE, 5 m/sec","755mm","96%","partly cloudy"));
        weatherInfos.add(new WeatherInfo("10.08.2007",location,"20C","NW, 7 m/sec","755mm","92%","cloudy"));
        weatherInfos.add(new WeatherInfo("11.08.2007",location,"30C","NW, 3 m/sec","755mm","75%","partly cloudy"));
        weatherInfos.add(new WeatherInfo("12.08.2007",location,"28C","NE, 1 m/sec","755mm","76%","cloudy"));
        weatherInfos.add(new WeatherInfo("13.08.2007",location,"27C","SW, 9 m/sec","755mm","77%","mostly cloudy"));
        weatherInfos.add(new WeatherInfo("14.08.2007",location,"29C","S, 12 m/sec","755mm","88%","sunny"));
        weatherInfos.add(new WeatherInfo("15.08.2007",location,"23C","SE, 11 m/sec","755mm","90%","cloudy"));
        weatherInfos.add(new WeatherInfo("16.08.2007",location,"27C","NW, 6 m/sec","755mm","95%","sunny"));
        weatherInfos.add(new WeatherInfo("17.08.2007",location,"20C","S, 4 m/sec","755mm","91%","mostly cloudy"));
    }
    
    public ArrayList getWeatherInfos() {
        return weatherInfos;
    }
    
    public int getSize() {
        return weatherInfos.size();
    }

}
