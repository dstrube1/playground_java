#!/bin/sh
#
#  $Id$
# 
#  Copyright 2007 Sun Microsystems, Inc. All rights reserved.
#  SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#

DIR=`pwd`
#JAVAFX_LIBRARY_PATH=
CLASSPATH=${DIR}/lib/smack.jar:{DIR}/lib/smackx.jar:${DIR}/..

export CLASSPATH

cd ../../
bin/javafx.sh casual.Main

