#!/bin/sh

#
#  $Id$
# 
#  Copyright 2007 Sun Microsystems, Inc. All rights reserved.
#  SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#

cd ../..
./bin/javafx.sh javafxpad.Main 
