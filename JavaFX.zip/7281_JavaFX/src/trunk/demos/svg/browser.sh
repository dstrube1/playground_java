#!/bin/sh

#
#  $Id$
# 
#  Copyright 2007 Sun Microsystems, Inc. All rights reserved.
#  SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#
FX_HOME=`dirname "$0"`/../..
FX_HOME=`cd "$FX_HOME" && pwd`

CLASSPATH=${FX_HOME}/demos/svg/lib/javafxsvg.jar:${FX_HOME}/demos/svg/lib/batik-awt-util.jar:${FX_HOME}/demos/svg/lib/batik-parser.jar:${FX_HOME}/demos/svg/lib/batik-util.jar:${FX_HOME}/demos/svg/lib/resolver.jar:${FX_HOME}/demos/ 

export CLASSPATH
${FX_HOME}/bin/javafx.sh svg.Browser


