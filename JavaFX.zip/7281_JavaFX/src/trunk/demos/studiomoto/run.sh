#!/bin/sh
#
#  $Id$
# 
#  Copyright 2007 Sun Microsystems, Inc. All rights reserved.
#  SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#

FX_HOME=`dirname "$0"`/../..
# Make the path absolute
FX_HOME=`cd "$FX_HOME" && pwd`
${FX_HOME}/bin/javafx.sh studiomoto.StudioMoto
